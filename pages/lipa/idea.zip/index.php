<!DOCTYPE html>

<html lang="zxx">

  <head>
    <meta charset="utf-8">
    <title>Pay ~ Two Plus</title>
  
    <!-- mobile responsive meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- ** Plugins Needed for the Project ** -->
    <!-- plugins -->
    <link rel="stylesheet" href="../plugins/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="../plugins/themify-icons/themify-icons.css">
    <!-- Main Stylesheet -->
    <link href="../css/style.css" rel="stylesheet">
    
    <!--Favicon-->
    <link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon">
    <link rel="icon" href="../images/favicon.ico" type="image/x-icon">
  
  </head>
  
  <body>
  
  <header class="sticky-top navigation">
    <div class=container>
      <nav class="navbar navbar-expand-lg navbar-light bg-transparent">
        <a class=navbar-brand href="../index.html"><strong>Two Plus</strong></a>
        <button class="navbar-toggler border-0" type="button" data-toggle="collapse" data-target="#navigation">
          <i class="ti-align-right h4 text-dark"></i></button>
        <div class="collapse navbar-collapse text-center" id=navigation>
          <ul class="navbar-nav mx-auto align-items-center">
            <li class="nav-item"><a class="nav-link" href="../index.html">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="#">About</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Payment options we support</a></li>
          </ul>
          <a href="../contact.html" class="btn btn-sm btn-primary ml-lg-4">contact </a>
        </div>
      </nav>
    </div>
  </header>

<section class="section">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="p-5 shadow rounded content">
          <h2 class="section-title">We need small info to process your order.</h2>
          <p>Note that you'll be making payment with <strong><i><? echo $_POST['option']?></i></strong></p>
          <form method="POST" action="pesapal-iframe.php">
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="fname">First Name</label>
                <input type="text" class="form-control" id="fname" name="fname" placeholder="Your First Name" required>
              </div>
              <div class="form-group col-md-6">
                <label for="lname">Last Name</label>
                <input type="text" class="form-control" id="lname" name="lname" placeholder="Your Last Name">
              </div>
            </div>
            <div class="form-group">
              <label for="email">Email</label>
              <input type="email" class="form-control" id="email" name="email" placeholder="Your Email Address"
                required>
            </div>
            <div class="form-group">
              <label for="reason">Ammount in <? echo $_POST['abr']?></label>
              <input type="text" class="form-control" id="amount" name="amount" value="<? echo $_POST['price']?>">
              <input type="hidden" name="currency" id="currency" value="<? echo $_POST['abr']?>" />
              <input type="hidden" name="reference" value="<?=uniqid()?>"  />
              
            </div>
            <div class="form-group">
              <label for="reason">Phone</label>
              <input type="phone" class="form-control" id="phone" name="phone" placeholder="+254..">
              
            </div>
            
            <button type="submit" id="submit" class="btn btn-primary">Send</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<footer>
  <div class="container">
    <div class="row align-items-center border-bottom py-5">
      <div class="col-lg-6">
        <ul class="list-inline footer-menu text-center text-lg-left">
          <li class="list-inline-item"><a href="#">Changelog</a></li>
          <li class="list-inline-item"><a href="../contact.html">contact</a></li>
          <li class="list-inline-item"><a href="#">Search</a></li>
        </ul>
      </div>
     
      <div class="col-lg-6">
        <ul class="list-inline social-icons text-lg-right text-center">
          <li class="list-inline-item"><a href="#"><i class="ti-facebook"></i></a></li>
          <li class="list-inline-item"><a href="#"><i class="ti-twitter-alt"></i></a></li>
          <li class="list-inline-item"><a href="#"><i class="ti-github"></i></a></li>
          <li class="list-inline-item"><a href="#"><i class="ti-linkedin"></i></a></li>
        </ul>
      </div>
    </div>
    <div class="py-4 text-center">
      <small class="text-light">Copyright © 2022 done by <a href="https://kapadokialabs.com">Kapadokia Labs</a></small>
    </div>
  </div>
</footer>

<!-- plugins -->
<script src="plugins/jQuery/jquery.min.js"></script>
<script src="plugins/bootstrap/bootstrap.min.js"></script>
<script src="plugins/masonry/masonry.min.js"></script>
<script src="plugins/clipboard/clipboard.min.js"></script>
<script src="plugins/match-height/jquery.matchHeight-min.js"></script>

<!-- Main Script -->
<script src="js/script.js"></script>
</body>
</html>